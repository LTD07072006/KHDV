"""Validate the workbook extracted by walkthrough_xlsx.mjs through the MVP adapter."""

from __future__ import annotations

import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
from jsonschema import Draft202012Validator

from workbook_adapter import build_request_from_frames


def frame_from_rows(rows: list[list[object]]) -> pd.DataFrame:
    return pd.DataFrame(rows[1:], columns=rows[0])


def main() -> None:
    extracted_path = Path(sys.argv[1])
    payload = json.loads(extracted_path.read_text(encoding="utf-8"))
    sheets = payload["sheets"]
    demand = frame_from_rows(sheets["NhuCau"])
    employees = frame_from_rows(sheets["NhanVien"])
    try:
        request, warnings = build_request_from_frames(
            demand,
            employees,
            "2026-11-02",
            request_id="req_2026-11-02_from_xlsx",
        )
    except ValueError as exc:
        result = {
            "source_file": payload["source_file"],
            "sheets": list(sheets),
            "result": "EXPECTED_VALIDATION_ERROR",
            "error": str(exc),
        }
        destination = Path("artifacts/walkthrough_error_result.json")
        destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, ensure_ascii=True))
        raise SystemExit(2)

    schema = json.loads(Path("docs/contracts/scheduling-request.schema.json").read_text(encoding="utf-8"))
    schema_errors = [error.message for error in Draft202012Validator(schema).iter_errors(request)]
    if schema_errors:
        raise SystemExit("Schema validation failed: " + "; ".join(schema_errors))

    output = {
        "source_file": payload["source_file"],
        "sheets": list(sheets),
        "demand_rows": len(demand),
        "employee_rows": len(employees),
        "working_employee_rows": len(request["employees"]),
        "slot_count": len(request["slots"]),
        "request_id": request["request_id"],
        "contract_version": request["contract_version"],
        "first_three_required_agents": [item["required_agents"] for item in request["demand"][:3]],
        "warnings": warnings,
        "schema_errors": schema_errors,
        "solver_status": "NOT_RUN_OR_TOY_SOLVER_PENDING",
        "solver_note": "CP-SAT end-to-end được bàn giao sang B2.2 vì môi trường walkthrough hiện chưa có OR-Tools.",
        "request": request,
    }
    destination = Path("artifacts/walkthrough_request_from_xlsx.json")
    destination.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: output[key] for key in output if key != "request"}, ensure_ascii=True))


if __name__ == "__main__":
    main()
