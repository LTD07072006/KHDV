import fs from 'node:fs/promises';
import { FileBlob, SpreadsheetFile } from '@oai/artifact-tool';

const workbookPath = process.argv[2] || 'D:/khdv/artifacts/mau_xep_lich.xlsx';
const outputPath = process.argv[3] || 'D:/khdv/artifacts/walkthrough_xlsx_input.json';
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(workbookPath));
const payload = { source_file: workbookPath, sheets: {} };

for (const name of ['HuongDan', 'NhuCau', 'NhanVien']) {
  const sheet = workbook.worksheets.getItem(name);
  payload.sheets[name] = sheet.getUsedRange(true).values;
}

await fs.writeFile(outputPath, JSON.stringify(payload, null, 2), 'utf8');
console.log(JSON.stringify({
  source_file: workbookPath,
  sheets: Object.keys(payload.sheets),
  demand_rows: payload.sheets.NhuCau.length - 1,
  employee_rows: payload.sheets.NhanVien.length - 1,
  output: outputPath,
}));
