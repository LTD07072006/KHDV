import fs from 'node:fs/promises';
import { FileBlob, SpreadsheetFile } from '@oai/artifact-tool';

const source = 'D:/khdv/artifacts/mau_xep_lich.xlsx';
const cases = [
  ['missing_required_header', (d, e) => { d.getRange('B1').values = [['so_cuoc_goi']]; }],
  ['outside_operating_hours', (d, e) => { d.getRange('A2').values = [['21:00–21:30']]; }],
  ['negative_calls', (d, e) => { d.getRange('B2').values = [[-1]]; }],
  ['duplicate_employee_id', (d, e) => { e.getRange('A3').values = [['NV001']]; }],
  ['working_employee_without_shift', (d, e) => { e.getRange('D2:F2').values = [['Không','Không','Không']]; }],
];

for (const [name, mutate] of cases) {
  const wb = await SpreadsheetFile.importXlsx(await FileBlob.load(source));
  mutate(wb.worksheets.getItem('NhuCau'), wb.worksheets.getItem('NhanVien'));
  const out = `D:/khdv/artifacts/case_${name}.xlsx`;
  const blob = await SpreadsheetFile.exportXlsx(wb);
  await blob.save(out);
  console.log(out);
}
