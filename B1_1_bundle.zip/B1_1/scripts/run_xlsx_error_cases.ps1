$node = 'C:\Users\Hp\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
& $node scripts/build_xlsx_error_cases.mjs | Out-Null
$rows = @()
foreach ($file in Get-ChildItem 'artifacts/case_*.xlsx') {
  $stem = [IO.Path]::GetFileNameWithoutExtension($file.Name)
  $input = "artifacts/$stem`_input.json"
  & $node scripts/walkthrough_xlsx.mjs $file.FullName $input | Out-Null
  $output = python scripts/validate_walkthrough_xlsx.py $input 2>&1
  if ($LASTEXITCODE -eq 0) {
    $rows += [PSCustomObject]@{Case=$stem; Result='FAIL'; Evidence='Không phát hiện lỗi'}
  } else {
    $rows += [PSCustomObject]@{Case=$stem; Result='PASS'; Evidence=($output -join ' ')}
  }
}
$rows | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 artifacts/xlsx_error_case_results.json
$rows | Format-Table -AutoSize
