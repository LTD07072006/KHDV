# B1.1 → Tuần 2: phiếu bàn giao triển khai

## Mục tiêu

Tuần 2 xây hệ thống trên một đầu vào duy nhất: workbook `mau_xep_lich.xlsx`. Người dùng nhập dữ liệu đơn giản; adapter chuyển dữ liệu đó thành `SchedulingRequest v1.0.0`; solver và giao diện không tự diễn giải lại các cột Excel.

## Hợp đồng đã chốt

- Một ngày lập lịch.
- Một nhóm mặc định: `Hỗ trợ chung` (`general_support`).
- Slot chuẩn: 30 phút.
- MVP không có lựa chọn nhập theo 1 giờ; dòng không dài đúng 30 phút bị từ chối.
- Nhu cầu người dùng nhập: số cuộc gọi dự kiến và AHT theo phút.
- Erlang C tự tính `required_agents`.
- Hai ca mẫu: `day_0800`, `day_0900`, `day_1100`.
- Không có bộ lọc ca toàn cục trên màn hình; ca được chọn theo từng nhân viên trong workbook.
- Một nhân viên tối đa một ca trong ngày.
- Shortage là soft result; request hợp lệ vẫn trả lịch và coverage thiếu.

## Bàn giao cho A

1. Dùng [example_scheduling_request_from_workbook.json](example_scheduling_request_from_workbook.json) làm fixture solver.
2. Giữ `required_agents` là giá trị do adapter/Erlang C phát hành.
3. Trả `assignments`, `coverage`, `understaffed` và `overstaffed` để UI hiển thị.
4. Không để solver đọc workbook hoặc CSV log.

## Bàn giao cho B2.1

1. Dựng model/validator theo [B1_1_final_input_output_spec.md](B1_1_final_input_output_spec.md).
2. Giữ đơn vị UI là phút và đơn vị contract Erlang là giây.
3. Dùng các thông báo lỗi tiếng Việt trong delivery plan.
4. Gọi `build_request_from_frames` trong [workbook_adapter.py](../workbook_adapter.py) từ lớp service.

## Bàn giao cho B2.2

1. Cho tải [mau_xep_lich.xlsx](../artifacts/mau_xep_lich.xlsx).
2. Cho upload `.xlsx`, chọn ngày, mức phục vụ và AHT chung nếu cần.
3. Hiển thị preview số dòng, khoảng giờ, số nhân viên đi làm và lỗi trước khi bấm “Tạo lịch”.
4. Sau khi solver trả kết quả, hiển thị trạng thái thân thiện và nút tải CSV.

## Việc không làm trong MVP

- Không upload raw call-log CSV ở luồng chính.
- Không cho nhập `required_agents`, skill ID, JSON hoặc solver options.
- Không forecast lịch sử nhiều tuần.
- Không thêm nhiều skill/channel, lịch nhiều ngày hoặc giờ làm tùy ý.

## Definition of Done tuần 2

- Workbook mẫu đọc được và preview đúng ba sheet.
- Dữ liệu hợp lệ sinh request qua adapter và request qua schema JSON.
- Ít nhất một input lỗi ở mỗi nhóm validation trả thông báo tiếng Việt có dòng/cột cần sửa.
- Fixture request chạy được qua solver toy.
- Coverage cho thấy được cần, đã xếp, thiếu và dư theo slot.
