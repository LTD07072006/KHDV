# B1.1 — Đặc tả INPUT/OUTPUT đã chốt

**Trạng thái:** bản chuẩn để A và B dùng chung sau tuần 1  
**Đối tượng sử dụng:** quản lý/trưởng nhóm chăm sóc khách hàng, không yêu cầu kiến thức IT  
**Phạm vi MVP:** một ngày, một nhóm `Hỗ trợ chung`, dữ liệu nhu cầu dự kiến, hai ca mẫu

## 1. Quyết định phạm vi

### 1.1. Luồng chính của MVP

Người dùng nhập nhu cầu dự kiến cho ngày cần xếp lịch và danh sách nhân viên có thể nhận từng ca mẫu.

```text
Chọn ngày
  → tải một file Excel mẫu
  → kiểm tra dữ liệu
  → hệ thống tự tính nhu cầu nhân viên
  → CP-SAT xếp ca
  → kiểm tra lịch
  → hiển thị và tải kết quả
```

Người dùng không nhập Erlang C, offered load, `required_agents`, quantile, shrinkage, occupancy, objective weight, seed, solver time limit hoặc JSON.

### 1.2. Ba nguồn nhu cầu và cách dùng

| Chế độ | Nguồn | Dùng trong MVP? | Cách xử lý |
|---|---|---:|---|
| **Nhu cầu dự kiến** | Số cuộc gọi và AHT đã ước lượng cho ngày cần lập lịch | **Có, mặc định** | Dùng trực tiếp làm đầu vào Erlang C |
| Lịch sử | Số cuộc gọi của nhiều ngày trước | Chưa đưa lên luồng chính | Dùng ở phiên bản forecast nâng cao |
| Nhu cầu nhân lực trực tiếp | Số người cần theo slot | Chỉ developer/test | Bỏ qua forecast và Erlang C |

Một lần chạy chỉ dùng **một** nguồn nhu cầu. Không trộn lịch sử, dự kiến và `required_agents` mà không ghi rõ nguồn nào là nguồn sự thật.

### 1.3. Độ phân giải thời gian

- Chuẩn nội bộ, file nhập và CP-SAT: **slot 30 phút**.
- MVP không có lựa chọn “Dữ liệu theo 1 giờ”. UI có thể nhóm hai slot thành một giờ khi hiển thị, nhưng dữ liệu nhập vẫn phải là hai dòng 30 phút.
- Nhập theo giờ là chức năng phiên bản sau, không thuộc contract MVP.

### 1.4. Ca làm

Ca mẫu được cấu hình sẵn; người dùng chỉ chọn ca nhân viên có thể nhận.

| Mã nội bộ | Nhãn người dùng | Khoảng trên đồng hồ | Break | Phút làm việc |
|---|---|---|---|---:|
| `day_0800` | Ca ngày | 08:00–20:00 | 12:00–13:00 | 480 |
| `day_0900` | Ca đêm | 20:00–08:00 ngày hôm sau | 00:00–01:00 | 480 |
| `day_1100` | Ca đêm | 20:00–08:00 ngày hôm sau | 00:00–01:00 | 480 |

`elapsed_span_minutes = 540`, `break_minutes = 60`, `productive_minutes = 480`. Tài liệu và schema không gọi 480 phút là toàn bộ khoảng từ start đến end.

### 1.5. Thiếu người

Thiếu người là biến mềm. Nếu input hợp lệ, solver vẫn trả lịch hợp lệ và bảng thiếu theo slot. `INFEASIBLE`/`INVALID_INPUT` chỉ dành cho dữ liệu hoặc hard constraint mâu thuẫn.

## 2. File người dùng nhập

Khuyến nghị một workbook `.xlsx` có ba sheet:

```text
HuongDan   # có sẵn, người dùng chỉ đọc
NhuCau     # người dùng điền
NhanVien   # người dùng điền
```

CSV được hỗ trợ ở phiên bản phụ nếu không thể dùng Excel. JSON chỉ dùng cho adapter/backend và fixture.

### 2.1. Sheet `NhuCau`

Mẫu MVP một nhóm:

| `khung_gio` | `so_cuoc_goi_du_kien` | `thoi_gian_xu_ly_trung_binh_phut` |
|---|---:|---:|
| 08:00–08:30 | 24 | 6 |
| 08:30–09:00 | 18 | 5 |
| 09:00–09:30 | 31 | 7 |

Quy tắc:

- `khung_gio` dùng dạng `HH:MM–HH:MM`; ngày lấy từ form.
- `so_cuoc_goi_du_kien` là số nguyên không âm.
- AHT là số phút dương. Có thể để trống nếu người dùng nhập “AHT chung” trên form.
- Bỏ trống `nhom_ho_tro` thì hệ thống dùng `Hỗ trợ chung`.
- Không nhập `required_agents` trong sheet này.

Khi mở rộng nhiều nhóm, thêm cột `nhom_ho_tro` bằng tên dễ hiểu như `Thoại` hoặc `Chat`; hệ thống tự tạo mã nội bộ.

### 2.2. Sheet `NhanVien`

Mẫu MVP:

| `ma_nhan_vien` | `ho_ten` | `di_lam` | `ca_ngay` | `ca_dem` | `ca_dem` |
|---|---|---|---|---|---|
| NV001 | Nguyễn Văn A | Có | Có | Không | Không |
| NV002 | Trần Thị B | Có | Không | Có | Không |
| NV003 | Lê Văn C | Không | Không | Không | Không |

Quy tắc:

- `ma_nhan_vien` duy nhất.
- `di_lam` nhận `Có/Không`, `Co/Khong`, `Yes/No` hoặc `1/0` rồi chuẩn hóa.
- Nhân viên `di_lam = Không` không được tạo candidate.
- Nhân viên `di_lam = Có` phải được chọn ít nhất một ca.
- Ca trong bảng ánh xạ trực tiếp vào các template đã cấu hình; không nhập giờ start/end tự do.
- MVP chỉ dùng một nhóm `Hỗ trợ chung`; cột nhóm/skill để phiên bản sau.

Không đưa vào file MVP: `skill_id`, contracted hours, `max_scheduled_minutes`, lịch sử 6 ngày, preference penalty, last shift end, objective hoặc solver options.

## 3. Các trường trên màn hình

| Nhãn | Bắt buộc | Mặc định | Ghi chú |
|---|---:|---|---|
| Ngày cần lập lịch | Có | ngày demo | MVP chỉ một ngày |
| AHT chung cho dòng trống | Có nếu có dòng thiếu AHT | 6 phút trong fixture | Không ghi đè AHT đã có theo dòng |
| Mức phục vụ | Không | Tiêu chuẩn | Tiêu chuẩn = 80%/20 giây; Cao = 90%/20 giây |
| Ca của từng nhân viên | Không | — | Chọn trực tiếp trong các cột `ca_ngay`, `ca_dem`, `ca_dem` của sheet `NhanVien` |

Giờ hoạt động MVP cố định trong khoảng 08:00–20:00. Không có form chọn giờ mở/đóng cửa và không có bộ lọc ca toàn cục; ca được chọn theo từng nhân viên trong workbook.

## 4. Validation và thông báo

### Lỗi chặn việc tạo lịch

- Thiếu sheet `NhuCau` hoặc `NhanVien`.
- Thiếu cột bắt buộc.
- Workbook không có dòng dữ liệu.
- Khung giờ sai, không dài đúng 30 phút hoặc ngoài giờ hoạt động MVP 08:00–20:00.
- Số cuộc gọi là chữ hoặc âm.
- AHT thiếu ở cả dòng và form, hoặc AHT không dương khi có cuộc gọi.
- Mã nhân viên trùng.
- Có nhân viên đi làm nhưng không chọn ca.
- Không có nhân viên nào đi làm.

Thông báo dùng tiếng Việt, ví dụ:

```text
Trang NhuCau chưa có cột “Số cuộc gọi dự kiến”.
Mã NV001 xuất hiện nhiều lần.
NV002 đang đi làm nhưng chưa chọn ca nào.
Khung 21:00–21:30 nằm ngoài giờ hoạt động MVP 08:00–20:00.
```

### Cảnh báo không chặn

- Không có cảnh báo chia đều trong MVP; khung giờ không dài đúng 30 phút là lỗi chặn.
- Một số slot không có nhu cầu.
- Nhu cầu lớn hơn năng lực nhân viên.
- Một số nhân viên chỉ nhận một ca.

## 5. Output

### 5.1. Output cho người quản lý

1. Bảng số cuộc gọi và AHT theo khoảng.
2. Số nhân viên cần theo khoảng.
3. Lịch: nhân viên, ngày, ca, break.
4. Độ phủ: cần, đã xếp, thiếu, dư.
5. Cảnh báo thiếu người và dữ liệu.
6. Nhãn trạng thái: `Lịch đã tạo`, `Lịch đã tạo nhưng còn thiếu người`, `Lịch cần xem lại`, `Không thể tạo lịch`.
7. Nút tải CSV lịch phân công.

### 5.2. Output kỹ thuật cho backend/A

Adapter phát hành `SchedulingRequest v1.0.0` với `required_agents` đã tính. Solver trả `SchedulingResult v1.0.0` gồm assignments, coverage, diagnostics, status, wall time, objective và gap. Các field kỹ thuật không hiển thị trong màn hình nhập liệu.

## 6. Các phần để phiên bản sau

- Forecast từ lịch sử nhiều tuần.
- Nhiều skill/channel.
- Nhiều ngày và history 6 ngày.
- Minimum floor theo nhóm.
- Sự kiện đặc biệt và hệ số tăng/giảm nhu cầu.
- Loại hợp đồng và số giờ tối thiểu.
- Cho phép đổi skill giữa các phần của ca.
- Tùy chỉnh objective, seed, time limit và diagnostic.

## 7. Checklist B1.1

- [x] Danh sách input.
- [x] Bảng so sánh phương án.
- [x] Phương án MVP được chọn.
- [x] Format workbook và cột mẫu.
- [x] Validation/lỗi/cảnh báo.
- [x] Output người quản lý và output backend.
- [x] Các quyết định phạm vi đã chốt: hai ca mẫu, một ngày, một skill.

**Kết luận:** Đây là đặc tả B1.1 dùng để chốt B2.1/B2.2 và adapter nhập liệu. Mọi tài liệu khác phải tuân theo quyết định trong file này.
