# B1.1 — Bằng chứng walkthrough adapter

Đã chạy trực tiếp trên file `artifacts/mau_xep_lich.xlsx` ngày 02/11/2026. File được mở bằng Artifact Tool, đọc đúng các sheet `HuongDan`, `NhuCau`, `NhanVien`, sau đó các sheet `NhuCau` và `NhanVien` được chuyển vào adapter MVP.

Evidence máy tạo ra:

- `artifacts/walkthrough_xlsx_input.json`: dữ liệu đọc trực tiếp từ workbook.
- `artifacts/walkthrough_request_from_xlsx.json`: request sinh ra từ workbook và kết quả kiểm schema.
- `artifacts/xlsx_error_case_results.json`: năm workbook lỗi được tạo từ file mẫu, đọc lại trực tiếp và đều trả lỗi validation mong đợi.

| Trường hợp | Kết quả | Bằng chứng |
|---|---|---|
| Workbook `.xlsx` hợp lệ | PASS | Đọc được 3 sheet; `NhuCau` có 18 dòng; `NhanVien` có 5 dòng, trong đó 4 người đi làm; request `req_2026-11-02_from_xlsx`; 18 slot; required đầu tiên `8,6,11`; schema errors `0` |
| Thiếu cột bắt buộc | PASS | Trang NhuCau thiếu cột bắt buộc: so_cuoc_goi_du_kien. |
| Khung giờ ngoài 08:00–20:00 | PASS | Dòng 2: khung giờ nằm ngoài giờ hoạt động 08:00–20:00. |
| Số cuộc gọi âm | PASS | Dòng 2: số cuộc gọi không được âm. |
| Mã nhân viên trùng | PASS | Mã NV001 xuất hiện nhiều lần. |
| Nhân viên đi làm chưa chọn ca | PASS | NV001 đang đi làm nhưng chưa chọn ca nào. |

### Các workbook lỗi chạy trực tiếp

| File biến thể | Kết quả | Thông báo |
|---|---|---|
| `case_missing_required_header.xlsx` | PASS | Thiếu cột `so_cuoc_goi_du_kien` |
| `case_outside_operating_hours.xlsx` | PASS | Khung giờ nằm ngoài 08:00–20:00 |
| `case_negative_calls.xlsx` | PASS | Số cuộc gọi không được âm |
| `case_duplicate_employee_id.xlsx` | PASS | Mã `NV001` xuất hiện nhiều lần |
| `case_working_employee_without_shift.xlsx` | PASS | Nhân viên đi làm nhưng chưa chọn ca |

Kết quả hợp lệ đầu tiên có `required_agents = 8, 6, 11`; request sinh ra có contract version `1.0.0`.

Walkthrough trực tiếp trên workbook đã đạt phần input → adapter → request → schema, gồm cả một workbook hợp lệ và năm workbook lỗi. CP-SAT end-to-end chưa chạy trong môi trường hiện tại vì chưa có `ortools`; việc nối solver và coverage UI chuyển sang B2.2.
