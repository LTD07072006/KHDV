# B1.1 — Kế hoạch phát triển và bàn giao chi tiết

**Chủ trì:** B  
**Mục tiêu:** chốt một thiết kế INPUT/OUTPUT đủ rõ để A xây solver, B2.1 định nghĩa contract và B2.2 xây màn hình nhập nhân viên mà không phải đoán semantics.

> Quyết định nghiệp vụ chuẩn nằm trong [B1_1_final_input_output_spec.md](D:/khdv/docs/B1_1_final_input_output_spec.md). Tài liệu này phát triển cách triển khai, cách kiểm tra và cách bàn giao quyết định đó.

## 1. B1.1 phải trả lời những câu hỏi nào?

Sau khi đọc B1.1, A và giảng viên phải biết chính xác:

1. Người dùng cuối nhập thông tin gì?
2. Người dùng nhập ở đâu: form hay file?
3. Một dòng dữ liệu có ý nghĩa gì?
4. Đơn vị của từng giá trị là gì?
5. Dữ liệu nào là bắt buộc, dữ liệu nào có thể bỏ trống?
6. Hệ thống tự tính gì sau khi người dùng bấm “Tạo lịch”?
7. Kết quả nào người dùng nhìn thấy?
8. Dữ liệu người dùng được đổi thành `SchedulingRequest` như thế nào?
9. Trường hợp dữ liệu sai hoặc thiếu người được xử lý ra sao?
10. Phần nào làm trong MVP và phần nào để sau?

## 2. Người dùng mục tiêu và kịch bản sử dụng

### 2.1. Người dùng mục tiêu

Người dùng là quản lý/trưởng nhóm trung tâm chăm sóc khách hàng. Họ có thể biết Excel cơ bản nhưng không cần biết lập trình hoặc tối ưu toán học.

Họ thường có hai nguồn thông tin:

- Bảng dự kiến lượng công việc cho ngày sắp tới.
- Danh sách nhân viên và ca mà từng người có thể nhận.

Họ không nhất thiết có log từng cuộc gọi hoặc biết số nhân viên cần theo Erlang C.

### 2.2. Kịch bản chính

```text
1. Quản lý chọn ngày 02/11/2026.
2. Tải file mau_xep_lich.xlsx.
3. Điền các khoảng giờ và số cuộc gọi dự kiến.
4. Điền nhân viên đi làm và ca có thể nhận.
5. Tải workbook lên hệ thống.
6. Chọn mức “Tiêu chuẩn”. Ca của từng nhân viên đã được chọn trong sheet `NhanVien`.
7. Xem bản xem trước và cảnh báo.
8. Bấm “Tạo lịch”.
9. Xem lịch, độ phủ và khoảng thiếu người.
10. Tải lịch phân công CSV.
```

### 2.3. Kịch bản không thuộc MVP

- Quản lý tải log từng cuộc gọi để hệ thống forecast nhiều tuần.
- Quản lý nhập trực tiếp số `required_agents`.
- Quản lý tự sửa trọng số objective hoặc time limit solver.
- Quản lý tự tạo skill ID hoặc JSON request.

Các kịch bản này chỉ là advanced/developer hoặc phiên bản sau.

## 3. Quyết định đầu vào chính thức

### 3.1. Form trên màn hình

| Mã | Nhãn người dùng | Bắt buộc | Mặc định | Giá trị nội bộ |
|---|---|---:|---|---|
| UI-01 | Ngày cần lập lịch | Có | ngày demo | `horizon.start/end` theo ngày |
| UI-03 | AHT chung cho dòng trống | Khi có dòng trống | 6 phút trong fixture | `aht_seconds = phút × 60` |
| UI-04 | Mức phục vụ | Không | Tiêu chuẩn | 0.80 trong 20 giây |

Không hiển thị các field nội bộ như `service_level`, `answer_within_seconds`, `shrinkage`, `occupancy`, `seed`, `objective_weight`.

### 3.2. Workbook

Workbook mẫu có ba sheet:

```text
HuongDan
NhuCau
NhanVien
```

`HuongDan` phải ghi rõ:

- Không đổi tên sheet.
- Không xóa dòng tiêu đề.
- Mỗi dòng `NhuCau` là một khoảng thời gian.
- Mỗi dòng `NhanVien` là một nhân viên.
- Điền `Có` hoặc `Không` ở các cột lựa chọn.
- Không nhập công thức vào các cột hệ thống sẽ đọc.

## 4. Đặc tả sheet `NhuCau`

### 4.1. Cột MVP

| Cột | Kiểu | Bắt buộc | Ví dụ | Quy tắc |
|---|---|---:|---|---|
| `khung_gio` | text | Có | `08:00–08:30` | Đúng một khoảng, kết thúc sau bắt đầu |
| `so_cuoc_goi_du_kien` | số nguyên | Có | `24` | `>= 0` |
| `thoi_gian_xu_ly_trung_binh_phut` | số thực | Có nếu không có AHT chung | `6` | `> 0` khi số cuộc gọi > 0 |

### 4.2. Cột mở rộng chưa bật

| Cột | Khi nào bật | Cách xử lý |
|---|---|---|
| `nhom_ho_tro` | Khi có nhiều nhóm | Tên hiển thị; adapter tự tạo ID |
| `ghi_chu` | Khi cần giải thích | Không đưa vào solver |
| `la_ngay_bat_thuong` | Khi có forecast lịch sử | Loại khỏi mẫu forecast sau khi người dùng xác nhận |

### 4.3. Quy tắc gộp và thiếu dữ liệu

- Trùng `khung_gio` trong cùng nhóm là lỗi, không tự cộng vì dễ nhập trùng.
- Thiếu một slot giữa giờ mở cửa và giờ đóng cửa là cảnh báo; MVP không tự thêm dòng và không tự chia nhu cầu.
- Dòng ngoài giờ hoạt động là lỗi chặn.
- Nếu AHT theo dòng trống nhưng có AHT chung trên form, dùng AHT chung và ghi provenance là `form_default`.

### 4.4. Dữ liệu theo giờ

Không thuộc MVP. Người dùng phải nhập từng dòng 30 phút. Nếu cần hỗ trợ dữ liệu theo giờ, phải mở change request và bổ sung quy tắc chia đều cùng provenance trước khi triển khai.

## 5. Đặc tả sheet `NhanVien`

### 5.1. Cột MVP

| Cột | Kiểu | Bắt buộc | Ví dụ | Quy tắc |
|---|---|---:|---|---|
| `ma_nhan_vien` | text | Có | `NV001` | duy nhất, không rỗng |
| `ho_ten` | text | Có | `Nguyễn Văn A` | chỉ hiển thị |
| `di_lam` | lựa chọn | Có | `Có` | chuẩn hóa Có/Không |
| `ca_ngay` | lựa chọn | Có | `Có` | map `day_0800` |
| `ca_dem` | lựa chọn | Có | `Không` | map `day_0900` |
| `ca_dem` | lựa chọn | Có | `Không` | map `day_1100` |

### 5.2. Quy tắc nghiệp vụ

- `di_lam = Không` → bỏ qua mọi lựa chọn ca, không sinh assignment.
- `di_lam = Có` và cả hai ca đều `Không` → lỗi chặn.
- `di_lam = Có` và nhiều ca `Có` → nhân viên có thể nhận một trong các ca đó; solver chọn tối đa một ca.
- Không dùng availability tùy ý trong MVP; giờ bắt đầu/kết thúc lấy từ template.
- Không dùng history 6 ngày cho horizon một ngày; field này được thêm trong phiên bản nhiều ngày.

### 5.3. Quy đổi sang domain nội bộ

Ví dụ:

```text
NV001, Có, ca_ngay=Có, ca_dem=Không, ca_dem=Không
```

được đổi thành các candidate được phép:

```text
(NV001, day_0800, Hỗ trợ chung)
```

Không tạo candidate `day_0900` hoặc `day_1100` cho NV001.

## 6. Bảng so sánh phương án nhập nhu cầu

| Phương án | Dữ liệu cần có | Độ dễ với non-IT | Giá trị học thuật | Rủi ro | Quyết định |
|---|---|---:|---:|---|---|
| Lịch sử nhiều tuần | ngày, giờ, nhóm, calls của nhiều ngày | Trung bình/thấp | Cao: có forecast | Thiếu dữ liệu, ngày bất thường, cần backtest | Advanced |
| Nhu cầu dự kiến theo slot | calls và AHT cho ngày cần xếp | Cao | Đủ để chứng minh Erlang + CP-SAT | Dựa vào ước lượng quản lý | **MVP** |
| Tổng calls/ngày + mẫu peak | tổng calls và kiểu phân bố | Cao | Thấp hơn | Hệ thống tự đoán sai giờ cao điểm | Không dùng làm luồng chính |
| `required_agents` trực tiếp | số người theo slot | Thấp vì khó hiểu | Tốt cho test solver | Bỏ qua forecast/Erlang | Developer fixture |

## 7. Chuỗi xử lý từ INPUT đến contract

```text
Workbook + form
    │
    ├─ validate workbook/user values
    ├─ normalize time, boolean, number and labels
    ├─ expand 1-hour rows only when selected
    ├─ create one default skill: Hỗ trợ chung
    ├─ instantiate selected shift templates for the chosen date
    ├─ calculate Erlang target for each slot
    └─ emit SchedulingRequest v1.0.0
```

Các field do adapter tự tạo:

| Field contract | Nguồn |
|---|---|
| `request_id` | hệ thống tạo từ ngày + lần chạy |
| `timezone` | cấu hình cố định Việt Nam |
| `horizon` | ngày trên form + giờ template |
| `slots` | sinh từ các mốc 30 phút |
| `skills` | tạo một skill `general_support` |
| `demand.forecast.expected_calls` | `so_cuoc_goi_du_kien` |
| `demand.forecast.aht_seconds` | AHT theo dòng hoặc AHT chung × 60 |
| `demand.erlang` | module Erlang C tự tính |
| `employees` | sheet `NhanVien` sau normalize |
| `shift_templates` | profile ca hệ thống |
| `rules/objective/solver_options` | backend defaults |

## 8. Output cần bàn giao

### 8.1. Bảng output cho người quản lý

| Output | Nội dung |
|---|---|
| Bảng nhu cầu | Khoảng giờ, calls, AHT, số người cần |
| Bảng lịch | nhân viên, ca, thời gian, break |
| Bảng độ phủ | cần, đã xếp, thiếu, dư |
| Cảnh báo | thiếu người, ca không đủ, một số slot không có nhu cầu, khoảng thời gian bị bỏ trống |
| File tải xuống | CSV lịch phân công và CSV độ phủ |
| Trạng thái | Lịch đã tạo / còn thiếu người / cần xem lại / lỗi dữ liệu |

### 8.2. Output kỹ thuật cho A

```text
SchedulingRequest v1.0.0
SchedulingResult v1.0.0
```

A không cần biết người dùng đã điền form hay Excel; A chỉ nhận request chuẩn.

## 9. Acceptance criteria cho B1.1

B1.1 được xem là hoàn thành khi:

- A có thể viết solver toy mà không hỏi lại ý nghĩa của `NhuCau` và `NhanVien`.
- B2.1 có thể tạo Pydantic/domain schema từ bảng field ở trên.
- B2.2 có thể làm form/upload không cần tự quyết định tên cột.
- Người dùng non-IT biết phải tải file nào, điền cột nào và bấm gì.
- Mỗi lỗi đầu vào có thông báo tiếng Việt và hướng sửa.
- Có một phương án MVP duy nhất; các phương án khác được gắn advanced/developer.
- `required_agents` và các field toán học không xuất hiện trong file người dùng.
- Slot nội bộ 30 phút và semantics ca 480 productive + 60 break không còn mâu thuẫn.

## 10. Checklist bàn giao từ B1.1 sang tuần 2

### Bàn giao cho A

- [x] Bảng ca mẫu và break đã chốt trong phiếu sign-off.
- [x] Quy tắc một ca/ngày và shortage mềm đã chốt.
- [x] Mapping `ca_ngay/ca_dem/ca_dem` → template ID.
- [x] Ví dụ request nội bộ từ một workbook.
- [x] Danh sách lỗi mà adapter sẽ loại trước solver.

### Bàn giao cho B2.1

- [x] Tên field UI và field contract.
- [x] Đơn vị: phút ở UI, giây ở contract Erlang.
- [x] Quy tắc slot 30 phút.
- [x] Quy tắc normalize Có/Không.
- [x] Các giá trị backend default.

### Bàn giao cho B2.2

- [x] Mẫu workbook.
- [ ] Preview sau upload.
- [x] Lỗi chặn/cảnh báo.
- [ ] Nút Tạo lịch và trạng thái đang xử lý.

## 11. Việc B nên làm tiếp theo

1. Gửi [B1_1_final_input_output_spec.md](D:/khdv/docs/B1_1_final_input_output_spec.md) và tài liệu này cho A để triển khai.
2. Bàn giao ba quyết định đã chốt: một ngày, một nhóm, slot 30 phút.
3. Tạo workbook `mau_xep_lich.xlsx` gồm `HuongDan`, `NhuCau`, `NhanVien`.
4. Tạo một bảng mapping UI → contract.
5. Ghi một ví dụ request JSON sinh từ workbook để A dùng cho solver toy.
6. Không mở rộng thêm trường kỹ thuật trước khi B2.1 hoàn tất.

## 12. Các quyết định để sau

- Forecast lịch sử 4–8 tuần.
- Nhiều nhóm/skill/channel.
- Lịch 7 ngày và history trước horizon.
- Minimum floor và loại hợp đồng.
- Cho phép đổi skill giữa ca.
- Sự kiện đặc biệt/outlier.
- Tùy chỉnh objective và solver.


## 13. Gói bàn giao đã tạo

### 13.1. Workbook mẫu

File [mau_xep_lich.xlsx](../artifacts/mau_xep_lich.xlsx) là mẫu nhập liệu thống nhất cho MVP. File có đúng ba sheet `HuongDan`, `NhuCau`, `NhanVien`; các ô người dùng cần điền được tô màu vàng và các cột lựa chọn ca có danh sách `Có/Không`. Đây là fixture dùng cho B2.2 và kiểm thử adapter.

### 13.2. Bảng ánh xạ chính thức

| Dữ liệu người dùng | Kiểu sau chuẩn hóa | Field trong request | Quy tắc |
|---|---|---|---|
| Ngày trên form | `YYYY-MM-DD` | `horizon.start/end`, timestamp slot | Gắn timezone `Asia/Ho_Chi_Minh` |
| `NhuCau.khung_gio` | khoảng 30 phút | `slots[].start/end` | Tạo `slot_01`, `slot_02`, ... theo thứ tự thời gian |
| `NhuCau.so_cuoc_goi_du_kien` | số thực không âm | `demand[].forecast.expected_calls` | Không làm tròn ở adapter |
| `NhuCau.thoi_gian_xu_ly_trung_binh_phut` | phút dương | `demand[].forecast.aht_seconds` | Nhân 60; nếu trống dùng AHT chung trên form |
| Nhãn mức phục vụ | profile nội bộ | `demand[].erlang.service_level`, `answer_within_seconds` | `Tiêu chuẩn = 0.80/20`; `Cao = 0.90/20` |
| `NhanVien.ma_nhan_vien` | mã duy nhất | `employees[].employee_id` | Trùng là lỗi chặn |
| `NhanVien.ho_ten` | chuỗi | `employees[].label` | Chỉ dùng hiển thị |
| `di_lam = Có` | boolean | availability/candidate | `Không` thì không sinh candidate |
| `ca_ngay/giữa/muộn = Có` | template ID | `shift_templates` + availability | Lần lượt `day_0800`, `day_0900`, `day_1100` |
| Số nhân viên Erlang C tính được | số nguyên | `demand[].required_agents`, `erlang.net_agents` | Người dùng không nhập |

### 13.3. Request mẫu để A dùng ngay

File [example_scheduling_request_from_workbook.json](example_scheduling_request_from_workbook.json) là request kỹ thuật sinh từ dữ liệu mẫu ngày 02/11/2026. Nó có 18 slot 30 phút, một skill `general_support`, bốn nhân viên đi làm và một nhân viên nghỉ. A có thể dùng file này làm fixture đầu vào cho solver toy; solver không cần đọc Excel.

### 13.4. Quy tắc adapter theo thứ tự thực hiện

1. Đọc đúng ba sheet và kiểm tra header bắt buộc.
2. Chuẩn hóa khoảng giờ, số, `Có/Không`; sắp xếp theo thời gian.
3. Kiểm tra lỗi chặn trước khi gọi Erlang C.
4. Tạo các slot 30 phút; input khác 30 phút là lỗi chặn trong MVP.
5. Tính Erlang C cho từng slot từ calls, AHT và profile mức phục vụ.
6. Tạo candidate ca theo các cột ca nhân viên; giới hạn một ca/ngày.
7. Phát hành `SchedulingRequest v1.0.0`; không để field giao diện lọt vào contract.
8. Ghi lại `warnings[]` và provenance để UI giải thích kết quả.

### 13.5. Tiêu chí nghiệm thu bổ sung

- Mở workbook mẫu bằng Excel hoặc LibreOffice thấy đủ ba sheet, header không bị đổi và ô nhập liệu dễ nhận biết.
- Với request mẫu, ba dòng đầu có `required_agents` lần lượt là 8, 6 và 11; đây là kết quả Erlang C của 24 cuộc gọi/AHT 6 phút, 18 cuộc gọi/AHT 5 phút và 31 cuộc gọi/AHT 7 phút ở mức 80% trong 20 giây.
- Adapter phải trả lỗi tiếng Việt trước solver khi gặp sheet thiếu, header thiếu, giờ sai, mã trùng hoặc nhân viên đi làm chưa chọn ca.
- Thiếu năng lực chỉ tạo warning và coverage shortage; không đổi thành `INFEASIBLE` nếu request vẫn hợp lệ.

### 13.6. Việc còn lại sau B1.1

- B2.1 hiện thực domain model và validator theo bảng ánh xạ.
- B2.2 dựng upload/preview và hiển thị lỗi tiếng Việt.
- A thay reader legacy bằng request adapter hoặc dùng fixture JSON trong solver toy.
- Khi ba bước trên chạy ổn mới nối workbook thật vào `app.py`; không bắt người dùng nhập CSV log kỹ thuật.

### 13.7. Trạng thái triển khai hiện tại

Đã có lớp [workbook_adapter.py](../workbook_adapter.py) làm ranh giới giữa dữ liệu non-IT và solver. Lớp này nhận hai bảng `NhuCau`/`NhanVien`, chuẩn hóa giá trị, kiểm tra lỗi tiếng Việt, tính Erlang C và phát hành request kỹ thuật. Hàm `build_request_from_workbook(...)` sẵn sàng được B2.2 gọi sau khi bổ sung dependency đọc Excel.

Trong giai đoạn chuyển tiếp, `app.py` vẫn đang đọc CSV log kiểu cũ. Không coi luồng CSV đó là luồng MVP; B2.2 cần thay file upload CSV bằng upload workbook và gọi adapter. Solver chỉ nên nhận request đã chuẩn hóa hoặc một fixture JSON, không đọc trực tiếp workbook.

## 14. Hướng đi chính đã phát triển thành pipeline

```text
Người quản lý
  → chọn ngày + mức phục vụ
  → điền mau_xep_lich.xlsx
  → upload và xem preview
  → adapter kiểm tra + chuẩn hóa
  → Erlang C tự tính số người cần
  → SchedulingRequest v1.0.0
  → CP-SAT xếp tối đa một ca/ngày
  → kiểm tra coverage độc lập
  → hiển thị lịch + shortage + CSV
```

### Điểm khóa để không lệch hướng

1. Workbook là giao diện nhập liệu, không phải contract của solver.
2. `required_agents` chỉ xuất hiện sau bước Erlang C.
3. Thiếu người là kết quả vận hành cần hiển thị, không phải lỗi solver.
4. Một ngày, một nhóm, slot 30 phút và ca mẫu là giới hạn để hoàn thành MVP.
5. Mọi mở rộng như forecast lịch sử, nhiều skill hoặc tùy chỉnh objective phải tạo change request riêng sau khi MVP chạy được.
