# B1.1 — Phiếu chốt trước khi chuyển sang tuần 2

Tài liệu này dùng để chốt các quyết định cuối cùng còn có thể gây hiểu khác nhau giữa B, A, B2.1 và B2.2.

## A. Các quyết định đã đủ cơ sở để chốt

- [x] MVP chỉ lập lịch cho **một ngày**.
- [x] MVP chỉ có một nhóm mặc định: **Hỗ trợ chung**.
- [x] Dữ liệu nhu cầu chính là **số cuộc gọi dự kiến + AHT**.
- [x] Đơn vị người dùng nhập AHT là **phút**; contract dùng **giây**.
- [x] Slot chuẩn của hệ thống là **30 phút**.
- [x] Có hai ca mẫu: sáng, giữa, muộn.
- [x] Một nhân viên tối đa nhận một ca trong một ngày.
- [x] Thiếu người là kết quả cảnh báo mềm; request hợp lệ vẫn trả lịch.
- [x] `required_agents` do Erlang C tự tính, người dùng không nhập.
- [x] Solver nhận `SchedulingRequest v1.0.0`, không đọc workbook.

## B. Các quyết định đã chốt

### B1. Ca được phép dùng trên màn hình

**Đã chốt:** bỏ trường chọn ca toàn cục khỏi MVP. Người dùng chỉ chọn `ca_ngay`, `ca_dem`, `ca_dem` trong sheet `NhanVien`; cách này tránh nhập trùng.

### B2. AHT chung khi ô AHT bị trống

**Đã chốt:** không đặt mặc định 6 phút trong sản phẩm thật. Nếu có ô trống, bắt người dùng nhập AHT chung; `6 phút` chỉ giữ trong fixture và tài liệu ví dụ.

### B3. Giờ hoạt động và dữ liệu theo giờ

**Đã chốt:** chỉ nhận khung 30 phút nằm trong 08:00–20:00 theo các ca mẫu. Nhập theo 1 giờ để sau MVP.

### B4. Cách chứng minh B1.1 đã đạt

**Đã thực hiện phần input walkthrough trực tiếp trên `.xlsx`.** Một workbook hợp lệ và năm workbook lỗi đã được đọc lại từ file, chạy qua adapter và lưu bằng chứng tại [B1_1_validation_evidence.md](B1_1_validation_evidence.md). Phần CP-SAT/coverage end-to-end thuộc B2.2 vì môi trường hiện tại chưa có OR-Tools.

Các trường hợp đã chạy:

1. Thiếu sheet/cột.
2. Khung giờ sai, không dài đúng 30 phút hoặc ngoài 08:00–20:00.
3. Số cuộc gọi âm/chữ hoặc AHT không hợp lệ.
4. Mã nhân viên trùng.
5. Nhân viên đi làm nhưng chưa chọn ca.

Kết quả cần lưu lại: preview, thông báo tiếng Việt, request JSON sinh ra, ba giá trị Erlang C đầu tiên và coverage từ solver.

## C. Việc phải làm ngay sau khi sign-off

- Dùng `B1_1_final_input_output_spec.md` làm đặc tả duy nhất.
- Dùng `B1_1_delivery_plan.md` làm kế hoạch triển khai.
- Gửi `B1_1_handoff_to_week2.md` cho A, B2.1 và B2.2.
- Chuyển các việc còn lại sang backlog tuần 2; không mở rộng thêm input MVP.

## D. Điều kiện đóng B1.1

B1.1 được đóng khi có đủ bốn bằng chứng:

1. Người phụ trách ghi nhận các mục B1–B3 đã chốt.
2. Workbook mẫu và request JSON mẫu được duyệt.
3. Bảng mapping UI → contract không còn field chưa định nghĩa.
4. Walkthrough validation chạy qua sáu trường hợp trên và có kết quả lưu lại.

Sau thời điểm này, mọi thay đổi về số ngày, số skill, ca tùy ý, forecast lịch sử hoặc tham số solver phải mở change request cho tuần 2 trở đi.
